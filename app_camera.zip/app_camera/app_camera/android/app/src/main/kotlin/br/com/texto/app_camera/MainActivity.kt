package br.com.texto.app_camera

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
